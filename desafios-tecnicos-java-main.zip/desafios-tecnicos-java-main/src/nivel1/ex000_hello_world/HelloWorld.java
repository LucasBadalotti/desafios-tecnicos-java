package nivel1.ex000_hello_world;

public class HelloWorld {
    public static void main(String[] args) {

        System.out.println("Hello World!");
    }
}